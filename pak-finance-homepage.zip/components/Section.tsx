import type { ReactNode } from "react";

export function Section({ id, eyebrow, title, copy, children, className = "" }: { id?: string; eyebrow?: string; title: string; copy?: string; children?: ReactNode; className?: string }) {
  return (
    <section id={id} className={`py-20 sm:py-24 ${className}`}>
      <div className="container-page">
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h2 className="section-title mt-4">{title}</h2>
        {copy && <p className="section-copy">{copy}</p>}
        {children}
      </div>
    </section>
  );
}
