 "use client";

import { ArrowRight, MessageCircle, Phone } from "lucide-react";

type CTAProps = {
  label?: string;
  variant?: "primary" | "secondary";
  event?: string;
  href?: string;
};

export function CTA({ label = "Get Free Consultation", variant = "primary", event = "consultation_click", href = "#contact" }: CTAProps) {
  const track = () => {
    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("lead-event", { detail: { event } }));
      const w = window as typeof window & { gtag?: (...args: unknown[]) => void };
      w.gtag?.("event", event);
    }
  };

  return (
    <a href={href} onClick={track} className={variant === "primary" ? "btn-primary" : "btn-secondary"}>
      {label}
      <ArrowRight size={17} />
    </a>
  );
}

export function ContactActions() {
  return (
    <div className="flex flex-wrap gap-3">
      <CTA />
      <a
        href="https://wa.me/923000000000"
        target="_blank"
        rel="noreferrer"
        onClick={() => window.dispatchEvent(new CustomEvent("lead-event", { detail: { event: "whatsapp_click" } }))}
        className="btn-secondary"
      >
        <MessageCircle size={17} /> Chat on WhatsApp
      </a>
      <a href="tel:+923000000000" className="btn-secondary" onClick={() => window.dispatchEvent(new CustomEvent("lead-event", { detail: { event: "phone_click" } }))}>
        <Phone size={17} /> Call
      </a>
    </div>
  );
}
