 "use client";

import { Menu, X } from "lucide-react";
import { useState } from "react";
import { CTA } from "./CTA";

const links = [
  ["Services", "#services"],
  ["Industries", "#industries"],
  ["Why Us", "#why-us"],
  ["Resources", "#resources"],
  ["About", "#about"],
];

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/70 bg-white/90 backdrop-blur-xl">
      <div className="container-page flex h-16 items-center justify-between gap-5">
        <a href="#" className="text-lg font-black tracking-tight text-navy">YOUR <span className="text-green">BRAND</span></a>
        <nav className="hidden items-center gap-7 lg:flex" aria-label="Primary navigation">
          {links.map(([label, href]) => <a key={label} href={href} className="text-sm font-semibold text-muted transition hover:text-navy">{label}</a>)}
        </nav>
        <div className="hidden lg:block"><CTA label="Get Free Consultation" /></div>
        <button aria-label={open ? "Close menu" : "Open menu"} className="rounded-lg p-2 text-navy hover:bg-slate-100 lg:hidden" onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <div className="border-t border-slate-100 bg-white px-5 py-4 lg:hidden">
          <nav className="container-page flex flex-col gap-1" aria-label="Mobile navigation">
            {links.map(([label, href]) => <a key={label} href={href} onClick={() => setOpen(false)} className="rounded-lg px-3 py-3 font-semibold text-navy hover:bg-slate-50">{label}</a>)}
            <div className="mt-2"><CTA /></div>
          </nav>
        </div>
      )}
    </header>
  );
}
