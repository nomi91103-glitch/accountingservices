 "use client";

import { useState } from "react";
import {
  ArrowRight, BarChart3, BookOpen, BriefcaseBusiness, Calculator, Check,
  ChevronDown, ClipboardCheck, Cloud, FileCheck2, FileText, Landmark,
  LineChart, ReceiptText, ShieldCheck, Sparkles, Users, WalletCards, Zap
} from "lucide-react";
import { Header } from "./Header";
import { FinanceDashboard } from "./Dashboard";
import { CTA, ContactActions } from "./CTA";
import { Section } from "./Section";

const problems = [
  ["Messy books", "Scattered records make it harder to understand what your business is really earning.", FileText],
  ["Late tax filing", "Deadlines and documentation can become stressful when finance work is left until the last minute.", ReceiptText],
  ["FBR notices", "Get organized support for responding to tax and compliance requirements.", ShieldCheck],
  ["Unclear cash flow", "Turn raw transactions into reports that make cash movement easier to understand.", LineChart],
  ["Payroll problems", "Keep payroll calculations and records structured as your team grows.", Users],
  ["Compliance deadlines", "Create a dependable workflow around recurring financial obligations.", ClipboardCheck],
];

const services = [
  ["Accounting", "Keep financial records structured and decision-ready.", Calculator],
  ["Bookkeeping", "Accurate day-to-day books, reconciliations and records.", BookOpen],
  ["Tax Services", "Practical support for tax preparation and filing.", ReceiptText],
  ["FBR Compliance", "Organize documentation and recurring compliance work.", ShieldCheck],
  ["Payroll", "Streamline payroll records and employee finance workflows.", Users],
  ["Audit & Assurance", "Clear financial review support built around your needs.", FileCheck2],
  ["Business Registration", "Get support organizing the financial side of starting a business.", Landmark],
  ["Corporate Compliance", "Keep recurring corporate finance obligations organized.", BriefcaseBusiness],
  ["Financial Advisory", "Use financial information to make more confident decisions.", LineChart],
  ["Virtual CFO", "Strategic finance support without a full-time CFO structure.", BarChart3],
  ["QuickBooks & Xero", "Modern cloud accounting workflows for growing businesses.", Cloud],
  ["Financial Reporting", "Useful management reports that turn numbers into insight.", FileText],
];

const industries = [
  ["Small Businesses", "Practical finance support for owner-led businesses."],
  ["Startups", "Build clean financial processes while you grow."],
  ["Ecommerce", "Organize sales, expenses, payouts and reporting."],
  ["Freelancers", "Keep business and personal finance records easier to manage."],
  ["IT Companies", "Finance workflows designed for digital businesses."],
  ["Agencies", "Improve project, client and operating visibility."],
  ["Retail", "Stay organized across sales, expenses and inventory-related records."],
  ["Restaurants", "Bring daily operations and financial reporting into one workflow."],
  ["Real Estate", "Structure property-related income and expense reporting."],
  ["Professional Services", "Reliable financial support for service-based firms."],
];

const faqs = [
  ["What accounting services do you provide?", "We provide accounting, bookkeeping, tax, FBR compliance, payroll, audit support, business registration, financial reporting and advisory services."],
  ["Do you work with small businesses?", "Yes. The homepage is designed around practical services for freelancers, startups, small businesses and growing companies."],
  ["Can you manage monthly bookkeeping?", "Yes. Monthly bookkeeping can include transaction recording, bank reconciliation, expense tracking and financial statements."],
  ["Do you help with FBR tax filing?", "Yes. Tax and compliance support can cover filing preparation, documentation and related FBR requirements."],
  ["Can you help register a new business?", "Yes. Business registration support can be structured around the needs and legal structure of the business."],
  ["Can I get a customized accounting package?", "Yes. Services can be combined around your business size, reporting needs and compliance requirements."],
];

function IconCard({ icon: Icon, title, copy }: { icon: any; title: string; copy: string }) {
  return <div className="card group p-5 transition duration-300 hover:-translate-y-1 hover:border-green/30 hover:shadow-soft">
    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-green/10 text-green transition group-hover:bg-green group-hover:text-white"><Icon size={21} /></div>
    <h3 className="mt-5 font-extrabold text-navy">{title}</h3>
    <p className="mt-2 text-sm leading-6 text-muted">{copy}</p>
  </div>;
}

export function Homepage() {
  const [faq, setFaq] = useState<number | null>(0);

  return (
    <>
      <Header />
      <main>
        <section className="overflow-hidden bg-white">
          <div className="container-page grid items-center gap-12 py-16 sm:py-20 lg:grid-cols-[1.02fr_.98fr] lg:py-24">
            <div>
              <span className="eyebrow">Accounting • Tax • Bookkeeping • Business Compliance</span>
              <h1 className="mt-6 max-w-3xl text-4xl font-black leading-[1.03] tracking-[-0.045em] text-navy sm:text-5xl lg:text-[4.35rem]">
                Smart Accounting &amp; Tax Solutions for Pakistani Businesses
              </h1>
              <p className="mt-6 max-w-2xl text-base leading-7 text-muted sm:text-lg">
                From bookkeeping and tax filing to FBR compliance and financial reporting, we help small businesses stay organized, compliant, and financially confident.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <CTA />
                <a href="#services" className="btn-secondary">Explore Services <ArrowRight size={17} /></a>
              </div>
              <p className="mt-5 text-xs font-semibold text-muted">Built for small businesses, startups, freelancers &amp; growing companies</p>
            </div>
            <FinanceDashboard />
          </div>
        </section>

        <section className="border-y border-slate-200 bg-surface">
          <div className="container-page grid gap-4 py-7 sm:grid-cols-2 lg:grid-cols-5">
            {["Accounting & Bookkeeping", "Tax & FBR Compliance", "Payroll Management", "Business Registration", "Financial Advisory"].map((x, i) => (
              <div key={x} className="flex items-center gap-3 text-sm font-bold text-navy"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-green shadow-sm">{i + 1}</span>{x}</div>
            ))}
          </div>
        </section>

        <Section title="Running a Business Is Hard Enough. Your Finances Shouldn't Be." copy="Replace scattered spreadsheets and deadline stress with a clearer financial workflow.">
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {problems.map(([title, copy, Icon]) => <IconCard key={String(title)} title={String(title)} copy={String(copy)} icon={Icon} />)}
          </div>
          <div className="mt-8"><CTA label="Let's Fix Your Financial Workflow" /></div>
        </Section>

        <Section id="services" className="bg-white" title="Everything Your Business Needs to Stay Financially Organized" copy="From everyday bookkeeping to tax compliance and strategic financial advice, get the essential financial services your business needs under one roof.">
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {services.map(([title, copy, Icon]) => <a href="#contact" key={String(title)} className="card group p-5 transition hover:-translate-y-1 hover:border-blue/20 hover:shadow-soft">
              <div className="flex items-start justify-between"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-navy/5 text-navy group-hover:bg-green/10 group-hover:text-green"><Icon size={19} /></div><ArrowRight size={16} className="text-slate-300 transition group-hover:translate-x-1 group-hover:text-green" /></div>
              <h3 className="mt-5 font-extrabold text-navy">{String(title)}</h3>
              <p className="mt-2 text-sm leading-6 text-muted">{String(copy)}</p>
              <span className="mt-4 inline-block text-xs font-bold text-blue">Learn More →</span>
            </a>)}
          </div>
        </Section>

        <Section title="Small Business Bookkeeping" copy="Keep your books accurate, organized and up to date without the hassle of managing everything yourself.">
          <div className="mt-10 grid items-center gap-10 lg:grid-cols-2">
            <div className="card p-6 sm:p-8">
              <ul className="grid gap-4 sm:grid-cols-2">
                {["Monthly bookkeeping", "Bank reconciliation", "Accounts payable & receivable", "Financial statements", "Expense tracking", "Catch-up bookkeeping"].map(x => <li key={x} className="flex gap-3 text-sm font-semibold text-navy"><span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-green/10 text-green"><Check size={12} /></span>{x}</li>)}
              </ul>
              <div className="mt-7"><CTA label="Get Bookkeeping Help" /></div>
            </div>
            <FinanceDashboard compact />
          </div>
        </Section>

        <Section id="why-us" className="bg-navy text-white" title="More Than an Accountant. Your Financial Partner." copy="A modern, practical approach to financial organization, compliance and business decision support.">
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {["Pakistan-focused expertise", "Transparent communication", "Modern accounting technology", "Small-business friendly", "Reliable compliance support", "Dedicated financial guidance"].map((x, i) => <div key={x} className="rounded-2xl border border-white/10 bg-white/5 p-6"><div className="text-2xl font-black text-green">0{i + 1}</div><h3 className="mt-5 font-extrabold">{x}</h3><p className="mt-2 text-sm leading-6 text-slate-300">A clear service experience designed around practical business needs.</p></div>)}
          </div>
        </Section>

        <Section title="Getting Started Is Simple">
          <div className="mt-10 grid gap-4 md:grid-cols-4">
            {["Book a Free Consultation", "Tell Us About Your Business", "We Build Your Financial Plan", "We Manage & Support Your Finances"].map((x, i) => <div key={x} className="relative rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><span className="text-sm font-black text-green">0{i + 1}</span><h3 className="mt-5 font-extrabold text-navy">{x}</h3>{i < 3 && <div className="absolute right-[-14px] top-10 hidden h-7 w-7 items-center justify-center rounded-full border border-slate-200 bg-white text-muted md:flex"><ArrowRight size={14} /></div>}</div>)}
          </div>
          <div className="mt-8"><CTA label="Start With a Free Consultation" /></div>
        </Section>

        <Section id="industries" className="bg-white" title="Accounting Solutions for Businesses Like Yours">
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {industries.map(([title, copy]) => <div key={title} className="card p-5"><div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue/10 text-blue"><BriefcaseBusiness size={17} /></div><h3 className="mt-4 font-extrabold text-navy">{title}</h3><p className="mt-2 text-xs leading-5 text-muted">{copy}</p></div>)}
          </div>
          <div className="mt-7"><a href="#contact" className="text-sm font-bold text-blue">View All Industries →</a></div>
        </Section>

        <section className="bg-surface py-20 sm:py-24">
          <div className="container-page grid items-center gap-10 lg:grid-cols-[1fr_.8fr]">
            <div>
              <span className="eyebrow">Pakistan Tax &amp; Compliance</span>
              <h2 className="section-title mt-4">Stay Compliant. Avoid Unnecessary Stress.</h2>
              <p className="section-copy">Get organized support for income tax filing, sales tax, NTN, STRN, FBR compliance, withholding tax, tax notices and documentation.</p>
              <div className="mt-7"><CTA label="Talk to a Tax Expert" /></div>
            </div>
            <div className="rounded-[1.5rem] bg-navy p-6 text-white shadow-soft">
              {["Income tax filing", "Sales tax", "NTN & STRN", "FBR compliance", "Withholding tax", "Tax notices", "Tax documentation"].map(x => <div key={x} className="flex items-center gap-3 border-b border-white/10 py-4 last:border-0"><Check size={17} className="text-green" /><span className="text-sm font-semibold">{x}</span></div>)}
            </div>
          </div>
        </section>

        <Section title="Simple, Transparent Service Plans" copy="Plans can be customized around your business needs.">
          <div className="mt-10 grid gap-5 lg:grid-cols-3">
            {[
              ["Starter", "For freelancers and small businesses"],
              ["Growing", "For growing businesses"],
              ["Complete", "For established businesses"],
            ].map(([title, subtitle], i) => <div key={title} className={`card p-7 ${i === 1 ? "border-green/40 ring-2 ring-green/10" : ""}`}><div className="flex items-center justify-between"><h3 className="text-xl font-black text-navy">{title}</h3>{i === 1 && <span className="rounded-full bg-green/10 px-2 py-1 text-[10px] font-bold text-green">POPULAR</span>}</div><p className="mt-2 text-sm text-muted">{subtitle}</p><div className="my-6 h-px bg-slate-100" />{["Bookkeeping", "Accounting", "Tax support", "Reporting", "Advisory"].map(x => <div key={x} className="mb-3 flex gap-2 text-sm text-navy"><Check size={16} className="text-green" />{x}</div>)}<a href="#contact" className="mt-5 block rounded-xl border border-slate-200 px-4 py-3 text-center text-sm font-bold text-navy hover:border-green/40">Get Custom Quote</a></div>)}
          </div>
        </Section>

        <Section className="bg-white" title="What Our Clients Say">
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {[1, 2, 3].map(i => <div key={i} className="card p-6"><div className="text-green">★★★★★</div><p className="mt-5 text-sm leading-7 text-muted">“Demo testimonial placeholder. Replace this copy with a verified client review before publishing.”</p><div className="mt-6 border-t border-slate-100 pt-4"><p className="text-sm font-extrabold text-navy">[Client Name]</p><p className="text-xs text-muted">[Business Name]</p></div></div>)}
          </div>
        </Section>

        <Section title="Real Financial Problems. Practical Solutions.">
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {["Small Business", "Ecommerce", "Startup"].map(x => <div key={x} className="card p-6"><span className="eyebrow">{x}</span><h3 className="mt-5 font-extrabold text-navy">Demo case study</h3><div className="mt-5 space-y-4 text-sm"><p><b>Challenge:</b> Placeholder for verified client problem.</p><p><b>Solution:</b> Placeholder for delivered service.</p><p><b>Result:</b> Placeholder for measured, verified outcome.</p></div></div>)}
          </div>
        </Section>

        <Section id="resources" className="bg-white" title="Business & Tax Insights">
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {["How to Keep Your Business Books Organized", "Tax Filing Basics for Pakistani Businesses", "What Every Small Business Should Know About FBR Compliance", "Bookkeeping vs Accounting: What's the Difference?"].map((x, i) => <a href="#contact" key={x} className="card group p-5"><span className="text-[10px] font-black uppercase tracking-widest text-green">{i % 2 ? "Tax" : "Accounting"}</span><h3 className="mt-4 font-extrabold leading-6 text-navy">{x}</h3><p className="mt-2 text-sm leading-6 text-muted">A future resource article will provide practical guidance for Pakistani business owners.</p><span className="mt-4 inline-block text-xs font-bold text-blue">Read Article →</span></a>)}
          </div>
        </Section>

        <Section title="Useful Tools for Business Owners" copy="Free tools can make everyday financial planning easier.">
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {["Tax Calculator", "Profit Margin Calculator", "Payroll Calculator", "Break-Even Calculator"].map(x => <div key={x} className="card p-5"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-green/10 text-green"><Zap size={18} /></div><h3 className="mt-5 font-extrabold text-navy">{x}</h3><p className="mt-2 text-sm text-muted">Coming soon as a dedicated free tool.</p></div>)}
          </div>
          <div className="mt-7"><a href="#contact" className="text-sm font-bold text-blue">Explore Free Tools →</a></div>
        </Section>

        <Section title="Frequently Asked Questions" copy="Quick answers to common questions about our accounting and tax support.">
          <div className="mt-10 max-w-4xl space-y-3">
            {faqs.map(([q, a], i) => <div key={q} className="overflow-hidden rounded-2xl border border-slate-200 bg-white"><button className="flex w-full items-center justify-between gap-5 p-5 text-left font-bold text-navy" onClick={() => setFaq(faq === i ? null : i)} aria-expanded={faq === i}><span>{q}</span><ChevronDown size={18} className={`shrink-0 transition ${faq === i ? "rotate-180 text-green" : ""}`} /></button>{faq === i && <div className="px-5 pb-5 text-sm leading-7 text-muted">{a}</div>}</div>)}
          </div>
        </Section>

        <section id="contact" className="bg-navy py-20 sm:py-24">
          <div className="container-page grid gap-10 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <span className="eyebrow border-white/10 bg-white/5 text-green">Let's Talk</span>
              <h2 className="mt-5 max-w-3xl text-4xl font-black tracking-[-0.04em] text-white sm:text-5xl">Let's Make Your Business Finances Simpler.</h2>
              <p className="mt-5 max-w-2xl text-base leading-7 text-slate-300">Get professional accounting, bookkeeping, tax and compliance support tailored to your business.</p>
              <div className="mt-8"><ContactActions /></div>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-6 text-sm text-slate-200">
              <p className="font-bold text-white">Contact placeholders</p>
              <p className="mt-4">Phone: +92 300 0000000</p>
              <p className="mt-2">Email: hello@example.com</p>
              <p className="mt-2">WhatsApp: +92 300 0000000</p>
            </div>
          </div>
        </section>
      </main>

      <footer id="about" className="border-t border-slate-200 bg-white">
        <div className="container-page grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
          <div><a href="#" className="text-lg font-black text-navy">YOUR <span className="text-green">BRAND</span></a><p className="mt-4 max-w-xs text-sm leading-6 text-muted">Modern accounting, bookkeeping, tax, compliance and financial advisory support for Pakistani businesses.</p></div>
          <div><h3 className="font-extrabold text-navy">Services</h3><div className="mt-4 space-y-2 text-sm text-muted">{["Accounting", "Bookkeeping", "Tax", "Payroll", "Audit", "Business Registration"].map(x => <a className="block hover:text-navy" href="#services" key={x}>{x}</a>)}</div></div>
          <div><h3 className="font-extrabold text-navy">Industries</h3><div className="mt-4 space-y-2 text-sm text-muted">{["Small Business", "Startups", "Ecommerce", "Freelancers", "IT Companies"].map(x => <a className="block hover:text-navy" href="#industries" key={x}>{x}</a>)}</div></div>
          <div><h3 className="font-extrabold text-navy">Company</h3><div className="mt-4 space-y-2 text-sm text-muted"><a className="block hover:text-navy" href="#about">About</a><a className="block hover:text-navy" href="#why-us">Why Us</a><a className="block hover:text-navy" href="#resources">Resources</a><a className="block hover:text-navy" href="#contact">Contact</a></div></div>
        </div>
        <div className="container-page flex flex-col gap-3 border-t border-slate-100 py-5 text-xs text-muted sm:flex-row sm:items-center sm:justify-between"><div>© 2026 YOUR BRAND. All rights reserved.</div><div className="flex gap-4"><a href="#contact">Privacy Policy</a><a href="#contact">Terms</a><a href="#contact">Disclaimer</a></div></div>
      </footer>

      <div className="fixed bottom-0 left-0 right-0 z-40 grid grid-cols-3 border-t border-slate-200 bg-white/95 p-2 shadow-2xl backdrop-blur lg:hidden">
        <a href="https://wa.me/923000000000" className="flex flex-col items-center gap-1 py-2 text-[10px] font-bold text-green"><span>WhatsApp</span></a>
        <a href="tel:+923000000000" className="flex flex-col items-center gap-1 border-x border-slate-100 py-2 text-[10px] font-bold text-navy"><span>Call</span></a>
        <a href="#contact" className="flex flex-col items-center gap-1 py-2 text-[10px] font-bold text-blue"><span>Free Consultation</span></a>
      </div>
    </>
  );
}
