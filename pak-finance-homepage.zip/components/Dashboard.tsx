import { ArrowDownRight, ArrowUpRight, BarChart3, CheckCircle2 } from "lucide-react";

export function FinanceDashboard({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`relative ${compact ? "" : "lg:ml-auto"} w-full max-w-xl`}>
      <div className="absolute -inset-6 rounded-[2rem] bg-gradient-to-br from-green/10 via-blue/5 to-transparent blur-2xl" />
      <div className="relative rounded-[1.5rem] border border-white/70 bg-white p-4 shadow-soft sm:p-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <p className="text-xs font-semibold text-muted">Financial overview</p>
            <p className="mt-1 text-lg font-extrabold text-navy">Demo dashboard</p>
          </div>
          <span className="rounded-lg bg-green/10 px-2.5 py-1 text-[10px] font-bold text-green">SAMPLE DATA</span>
        </div>
        <div className="grid grid-cols-2 gap-3 py-4 sm:grid-cols-4">
          {[
            ["Monthly Revenue", "PKR 2.45M", true],
            ["Expenses", "PKR 1.32M", false],
            ["Net Profit", "PKR 1.13M", true],
            ["Tax Status", "Up to Date", true],
          ].map(([title, value, positive]) => (
            <div key={String(title)} className="rounded-xl bg-surface p-3">
              <p className="text-[10px] font-medium text-muted">{title}</p>
              <p className="mt-1 text-sm font-extrabold text-navy">{value}</p>
              <div className={`mt-2 flex items-center gap-1 text-[10px] font-bold ${positive ? "text-green" : "text-blue"}`}>
                {positive ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                Demo metric
              </div>
            </div>
          ))}
        </div>
        <div className="rounded-xl border border-slate-100 p-4">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-navy">Revenue vs. expenses</p>
              <p className="text-[10px] text-muted">Illustrative trend</p>
            </div>
            <BarChart3 size={17} className="text-green" />
          </div>
          <div className="flex h-28 items-end gap-2">
            {[38, 55, 44, 72, 60, 86, 76, 94, 80, 100, 91, 108].map((h, i) => (
              <div key={i} className="flex flex-1 items-end gap-1">
                <div className="w-1/2 rounded-t bg-navy/15" style={{ height: `${h * 0.62}%` }} />
                <div className="w-1/2 rounded-t bg-green/70" style={{ height: `${h}%` }} />
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-4 text-[10px] text-muted">
            <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-full bg-green/70" /> Revenue</span>
            <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-full bg-navy/15" /> Expenses</span>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-2 rounded-xl bg-navy p-3 text-white">
          <CheckCircle2 size={17} className="text-green" />
          <span className="text-xs font-semibold">Compliance checklist is ready for review.</span>
        </div>
      </div>
    </div>
  );
}
