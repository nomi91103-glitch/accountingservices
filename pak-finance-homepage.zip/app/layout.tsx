import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Accounting, Bookkeeping & Tax Services in Pakistan | YOUR BRAND",
  description:
    "Professional accounting, bookkeeping, tax filing, FBR compliance, payroll and financial advisory services for small businesses in Pakistan.",
  alternates: { canonical: "https://example.com/" },
  openGraph: {
    title: "Accounting, Bookkeeping & Tax Services in Pakistan | YOUR BRAND",
    description:
      "Professional accounting, bookkeeping, tax filing, FBR compliance, payroll and financial advisory services for small businesses in Pakistan.",
    type: "website",
    url: "https://example.com/",
    siteName: "YOUR BRAND",
  },
  twitter: {
    card: "summary_large_image",
    title: "Accounting, Bookkeeping & Tax Services in Pakistan | YOUR BRAND",
    description:
      "Professional accounting, bookkeeping, tax filing, FBR compliance, payroll and financial advisory services for small businesses in Pakistan.",
  },
  robots: { index: true, follow: true },
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "YOUR BRAND",
  url: "https://example.com/",
  description:
    "Accounting, bookkeeping, tax, payroll, compliance and financial advisory services for businesses in Pakistan.",
};

const websiteSchema = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "YOUR BRAND",
  url: "https://example.com/",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en-PK">
      <head>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
