import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        navy: "#0B1F3A",
        green: "#00A878",
        blue: "#2563EB",
        ink: "#0F172A",
        muted: "#64748B",
        surface: "#F8FAFC",
      },
      boxShadow: {
        soft: "0 20px 60px rgba(11,31,58,.10)",
        card: "0 10px 30px rgba(15,23,42,.07)",
      },
    },
  },
  plugins: [],
};

export default config;
